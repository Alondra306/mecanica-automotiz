from flask import Flask, render_template, request, redirect, url_for, session  # Importar session
from controllers.AuthController import AuthController
from controllers.EmpleadoController import EmpleadoController

app = Flask(__name__)

auth_controller = AuthController()
empleado_controller = EmpleadoController()

# Establece una clave secreta para manejar las sesiones
app.secret_key = 'tu_clave_secreta_aqui'

@app.route('/')
def login_form():
    return render_template('login.html')
    
@app.route('/login', methods=['POST'])
def login():
    username = request.form['usuario']
    password = request.form['password']
    
    if auth_controller.validar_usuario(username, password):
        session['usuario'] = username  # Almacena el usuario en la sesión
        return redirect(url_for('inicio'))  # O redirige a otra página si lo deseas
    else:
        return "Usuario o contraseña incorrectos."

@app.route('/registro', methods=['GET', 'POST'])
def registro():
    if request.method == 'POST':
        try:
            nombre = request.form['nombre']
            apellido = request.form['apellido']
            telefono = request.form['telefono']
            fecha_nacimiento = request.form['fecha_nacimiento']
            rfc = request.form['rfc']
            cargo = request.form['cargo']
            genero = request.form['genero'] 
            comentarios = request.form['comentarios']
            correo = request.form['correo'] 
            password = request.form['password']  
            
           # Registrar el empleado
            registro_exitoso = empleado_controller.registrar_empleado(nombre, apellido, telefono, fecha_nacimiento, rfc, cargo, genero, comentarios, correo, password)

            if registro_exitoso:
                return redirect(url_for('inicio'))
            else:
                return "Error al registrar el empleado :(", 500
        except KeyError as e:
            return f"Falta el campo requerido: {e}", 400
        
    return render_template('empleados.html')  # Formulario de registro de empleados
  
@app.route('/inicio')
def inicio():
    return render_template('header.html') 

if __name__ == '__main__':
    app.run(debug=True)
