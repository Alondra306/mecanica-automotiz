from models.user import User

class AuthController:
    def validar_usuario(self, username, password):
        usuario = User.buscar_usuario(username)
        if usuario:
            usuario_bd, password_bd = usuario
            # Compara las credenciales ingresadas con las almacenadas en la base de datos
            return password_bd == password
        else:
            return False
