from models.database import conectar

class EmpleadoController:
    def __init__(self):
        self.conexion = conectar() 

    def registrar_empleado(self, nombre, apellido, telefono, fecha_nacimiento, rfc, cargo, genero, comentarios, correo, password):
        try:
            cursor = self.conexion.cursor()

            query = """
                INSERT INTO registro
                (nombre, apellido, telefono, fecha_nacimiento, rfc, cargo, genero, comentarios,correo, password)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """
            
            valores = (nombre, apellido, telefono, fecha_nacimiento,  rfc, cargo, genero, comentarios, correo, password)
            cursor.execute(query, valores)
            self.conexion.commit()

            return True  # Registro exitoso
        except Exception as e:
            print(f"Error al registrar: {e}")
            return False
