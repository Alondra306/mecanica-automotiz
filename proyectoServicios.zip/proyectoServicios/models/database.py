import mysql.connector

def conectar():
    try:
        conexion = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="empleados"
        )
        if conexion.is_connected():
            print("¡Conexión exitosa a la base de datos!")
            return conexion #retorna la conexion a user y controller
    except mysql.connector.Error as err:
        print(f"Error: {err}")
        return None
    
if __name__ == "__main__":
    conectar()