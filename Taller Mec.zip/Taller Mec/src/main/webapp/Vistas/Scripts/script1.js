// Toggle de acordeón
function toggleAcordeon(boton, categoria) {
    var contenido = document.getElementById("contenido-" + categoria);
    var flecha = boton.querySelector(".arrow");

    if (!contenido || !flecha) return;

    if (contenido.style.display === "none" || contenido.style.display === "") {
        contenido.style.display = "block";
        boton.classList.add("activo");
        flecha.innerHTML = "⌃"; // Flecha hacia arriba
    } else {
        contenido.style.display = "none";
        boton.classList.remove("activo");
        flecha.innerHTML = "⌄"; // Flecha hacia abajo
    }
}

// Validación de los servicios seleccionados
function validarServicios() {
    var checkboxes = document.querySelectorAll('input[name="servicio"]:checked');
    if (checkboxes.length === 0) {
        alert("Por favor, selecciona al menos un servicio antes de registrarte.");
        return false; // Evita el envío del formulario
    }
    return true; // Permite el envío si hay al menos un servicio seleccionado
}
