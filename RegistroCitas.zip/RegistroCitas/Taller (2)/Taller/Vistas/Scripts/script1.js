// Toggle de acordeón
function toggleAcordeon(boton, categoria) {
    var contenido = document.getElementById("contenido-" + categoria);
    var flecha = boton.querySelector(".arrow");

    if (!contenido || !flecha) return;

    if (contenido.style.display === "none" || contenido.style.display === "") {
        contenido.style.display = "block";
        boton.classList.add("activo");
        flecha.innerHTML = "⌃"; // Flecha hacia arriba
    } else {
        contenido.style.display = "none";
        boton.classList.remove("activo");
        flecha.innerHTML = "⌄"; // Flecha hacia abajo
    }
}

