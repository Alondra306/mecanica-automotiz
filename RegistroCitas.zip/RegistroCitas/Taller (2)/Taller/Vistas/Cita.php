<script>
function enviarCita() {
    const phoneInput = window.intlTelInputGlobals.getInstance(
        document.querySelector("#telefono")
    );
    const codigoPais = phoneInput.getSelectedCountryData().dialCode;
    
    const formData = {
        nombre: document.getElementById('nombre').value,
        apellido: document.getElementById('apellido').value,
        email: document.getElementById('email').value,
        codigo_pais: codigoPais,
        telefono: document.getElementById('telefono').value,
        servicios: Array.from(
            document.querySelectorAll('input[name="servicio"]:checked')
        ).map(el => el.value),
        fecha_hora: document.getElementById('fecha-hora').value
    };
    
    // Enviar a PHP
    fetch('http://localhost/Taller/php/api/citas.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData)
    })
    .then(response => response.json())
    .then(data => {
        alert(data.mensaje || data.error);
        if(response.ok) {
            window.location.href = '../index.php'; 
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error al enviar la cita');
    });
}
</script>