<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>MecanicaCUT</title>
<link href="css/IndexStyle.css" rel="stylesheet" type="text/css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.css">
<script src="Scripts/script1.js" defer></script>
</head>

<body>
<header role="banner" class="header">
    <div class="logo">
        <img
            src="Logo.png"
            alt="Logo"
            class="logo-img"
        />
    </div>
    <nav class="navbar">
        <ul>
        <li><a>Inicio</a></li>
        <li><a href="#productos">Productos</a></li>
        <li><a href="#servicios">Servicios</a></li>
        <li><a href="#registro-cita" class="cita">Crear Cita</a></li>
        </ul>
    </nav>
</header>

<section id="productos">
    <h2>Productos</h2>
    <div class="producto-list">
        <article class="producto">
            <img src="css/imagenes/suspension.jpg">
            <h3>Suspensiones</h3>
        </article>
        <article class="producto">
            <img src="css/imagenes/llantas.jpg">
            <h3>Llantas</h3>
        </article>
        <article class="producto">
            <img src="css/imagenes/aceite.jpg">
            <h3>Aceite</h3>
        </article>
        <article class="producto">
            <img src="css/imagenes/bateria.jpeg">
            <h3>Batería para Autos</h3>
        </article>
        <article class="producto">
            <img src="css/imagenes/jump.jpg">
            <h3>Cables para corriente</h3>
        </article>
        <article class="producto">
            <img src="css/imagenes/kit.jpg">
            <h3>Kit de Limpieza</h3>
        </article>
        <article class="producto">
            <img src="css/imagenes/caralarm.png">
            <h3>Alarma de Coche</h3>
        </article>
        <article class="producto">
            <img src="css/imagenes/tapete.jpg">
            <h3>Tapetes para Coche</h3>
        </article>
        <article class="producto">
            <img src="css/imagenes/cera.jpg">
            <h3>Cera para Coche</h3>
        </article>
    </div>
</section>

<section id="servicios">
    <h2>Servicios</h2>
    <div class="servicios-container">
        <div class="about-card">
            <h3>Cambio de Aceite</h3>
            <p>
                Cambio de Aceite para prevenir desgaste entre las piezas del motor <br><br><br>
            </p>
            <img src="css/imagenes/oilchange.png" class="bottom-image">
        </div>
        <div class="about-card">
            <h3>Revisiones</h3>
            <p>
                Queremos ofrecer revisiones a nuestros clientes para prevenir desgastes y cuidar el estado de su vehículo <br><br>
            </p>
            <img src="css/imagenes/repair.jpg" class="bottom-image">
        </div>
        <div class="about-card">
            <h3>Mantenimiento</h3>
            <p>
                Realizar revisión para tener un panorama más claro sobre el estado de tu vehículo y planificar los próximos servicios antes de presentar una falla
            </p>
            <img src="css/imagenes/carmain.png" class="bottom-image" />
        </div>
    </div>
</section>

<!-- Registro de Cita-->

<?php include __DIR__ . '/../Models/Conexion_db.php';
    $db= new Database();
?>

<section id="registro-cita">
    <h2>Registro de citas</h2>
    <div class="container">


    <form class="registroDeCitas" id="registroDeCitas" method="post">

        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required><br>

        <label for="apellido">Apellido:</label>
        <input type="text" id="apellido" name="apellido" required><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br>

        <label for="telefono">Teléfono:</label>
        <input type="tel" id="telefono" name="telefono" required><br>
        <input type="hidden" name="codigo_pais" id="codigo_pais">

        <label for="servicio">Servicios:</label>
        <div class="accordion">
            <div class="accordion-item" id="servicios-container">
                <button type="button" class="accordion-header btn-acordeon">Servicios<span class="arrow">⌄</span> </button>                
            </div>
        </div><br>
        <input type="hidden" id="servicios-seleccionados" name="servicio">

        <!-- Este campo oculto contendrá los valores seleccionados  <input type="hidden" id="servicios-seleccionados" name="servicios"> -->

        <label for="fecha-hora">Selecciona fecha y hora:</label>
        <input type="datetime-local" id="fecha-hora" name="fecha_hora" required>

        <button type="submit" name="Registro" >Registrarse</button>
    </form>
</div>
</section>

<!-- Script para preparar el campo oculto -->
<script>
    function validarServicios() {
        var checkboxes = document.querySelectorAll('.form-check-input:checked');
        if (checkboxes.length === 0) {
            alert("Por favor, selecciona al menos un servicio antes de registrarte.");
            return false; 
        }
        return true; 
    }

    async function cargarServicios() {
    try {
        const response = await fetch('http://localhost:8023/Controllers/ServiceController.php');
   
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        
        if (Array.isArray(data)) {
            const serviciosContainer = document.getElementById('servicios-container');
            const existingButton = serviciosContainer.querySelector('.accordion-header');
            serviciosContainer.innerHTML = '';
            if (existingButton) {
                serviciosContainer.appendChild(existingButton);
            }
            
            const contentDiv = document.createElement('div');
            contentDiv.className = 'accordion-content';
            contentDiv.style.display = 'none';
            contentDiv.id = 'contenido-mantenimiento';
            
            data.forEach(servicio => {
                const checkboxDiv = document.createElement('div');
                checkboxDiv.className = 'form-check';

                checkboxDiv.innerHTML = `
                    <label class="form-check-label" for="servicio-${servicio.ID}">
                        <input class="form-check-input" type="checkbox" 
                            value="${servicio.ID}" 
                            id="servicio-${servicio.ID}"
                            data-precio="${servicio.ServicePrice}"
                            data-nombre="${servicio.ServiceName}">
                        ${servicio.ServiceName}
                    </label>
                `;
                contentDiv.appendChild(checkboxDiv);
            });
            
            serviciosContainer.appendChild(contentDiv);
            const accordionButton = serviciosContainer.querySelector('.accordion-header');
            if (accordionButton) {
                accordionButton.onclick = function() {
                    toggleAcordeon(this, 'mantenimiento');
                };
            }
        }
    } catch (error) {
        console.error('Error cargando servicios:', error);
        showNotification('Error al cargar servicios: ' + error.message, 'error');
    }
}

$(document).ready(function(){
    $(".registroDeCitas").submit(function(event){
        event.preventDefault(); 
        if(validarServicios() && validarHorarioCita()){
            var checkboxes = document.querySelectorAll('.form-check-input:checked');

            var servicios = Array.from(checkboxes).map(cb => cb.dataset.nombre);
            document.getElementById('servicios-seleccionados').value = servicios.join(',');

            setTimeout(() => {
                var formData = $(this).serialize();
                //////////////////
                $.ajax({
                    type: "POST",
                    url: "/Controllers/EmailController.php",
                    data: JSON.stringify({
                        nombre: $('#nombre').val(),
                        apellido: $('#apellido').val(),
                        email: $('#email').val(),
                        telefono: $('#telefono').val(),
                        servicios: $('#servicios-seleccionados').val(),
                        fecha_hora: $('#fecha-hora').val(),
                        is_completed: false
                    }),
                    contentType: "application/json",
                    dataType: "json",
                    success: function(response){
                        console.log("Email response:", response);
                        if(response.success){
                            alert("Correo enviado con éxito");
                        } else {
                            alert("Error al enviar correo");
                        }
                    },
                    error: function(xhr, status, error){
                        console.error("Email error:", error);
                    }
                });

/////////////////////////////////////
                console.log("Form data: ", formData);
                $.ajax({
                    type: "POST", 
                    url: "/Controllers/CitaController.php",
                    data: formData,
                    dataType: "json",
                    success: function(response){
                        console.log("Response from server: ", response);
                        if(response.success){
                            alert("Cita registrada"); 
                            $(".registroDeCitas")[0].reset();
                        }else{
                            alert("Error al registrar cita: " + response.message);
                        }
                    },
                    error: function(xhr, status, error){
                        console.log("AJAX error:", xhr.responseText);
                        alert("Error al enviar la solicitud. Por favor verifica tu conexión.");
                    }
                });
            }, 0); 
        }
    });
});
</script>

<!-- Script para lo del codigo_país -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js"></script>

<script>
    document.addEventListener('DOMContentLoaded', function() {

        const phoneInput = document.querySelector("#telefono");
        const iti = window.intlTelInput(phoneInput, {
            initialCountry: "mx",
            preferredCountries: ["mx", "us", "es", "co", "ar", "br", "cl"],
            separateDialCode: true,
            utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js"
        });
        phoneInput.addEventListener("countrychange", function() {
            document.querySelector("#codigo_pais").value = iti.getSelectedCountryData().dialCode;
        });
        document.querySelector("#codigo_pais").value = iti.getSelectedCountryData().dialCode;
        
    });
</script>



<!-- Script para validar el horario de la cita-->
<script>
function validarHorarioCita() {
    const fechaHoraInput = document.getElementById('fecha-hora');
    const fechaHoraSeleccionada = new Date(fechaHoraInput.value);
    
    const horas = fechaHoraSeleccionada.getHours();
    const minutos = fechaHoraSeleccionada.getMinutes();
    
    // Validar que esté entre 8:00 y 22:00 (10:00 p.m.)
    if (horas < 8 || (horas === 22 && minutos > 0) || horas >= 23) {
        alert("Las citas solo están disponibles entre las 8:00 a.m. y las 10:00 p.m.");
        return false;
    }
    
    //  NO fechas pasadas
    const ahora = new Date();
    if (fechaHoraSeleccionada <+ ahora) {
        alert("No se pueden agendar citas en fechas u horas pasadas.");
        return false;
    }
    
    return true;
}

document.addEventListener('DOMContentLoaded', function() {
    cargarServicios();
    const fechaHoraInput = document.getElementById('fecha-hora');
    
    const ahora = new Date();
    const fechaMinima = new Date(ahora.getTime() - ahora.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
    fechaHoraInput.min = fechaMinima;
    
    // Aca, hay como un limite de cuantos meses se pueden agendar, en este caso 3 meses (por si eso lo quieren quitar o cambiar es solo estetico)
    const fechaMaxima = new Date();
    fechaMaxima.setMonth(fechaMaxima.getMonth() + 3);
    fechaHoraInput.max = fechaMaxima.toISOString().slice(0, 16);
});
</script>

</body>
</html>
