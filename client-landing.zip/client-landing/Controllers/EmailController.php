<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');
$data = json_decode(file_get_contents("php://input"), true);

require_once '../vendor/autoload.php';

class EmailSender {
    private $smtpUser = 'alejandro.limon4634@alumnos.udg.mx';
    private $smtpPass = 'gqyh tdwl qgub hmyf';
    private $smtpHost = 'smtp.gmail.com';
    private $smtpPort = 587;

    public function send($data) {
        $mail = new PHPMailer(true);
        
        try {
            $mail->isSMTP();
            $mail->Host = $this->smtpHost;
            $mail->SMTPAuth = true;
            $mail->Username = $this->smtpUser;
            $mail->Password = $this->smtpPass;
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = $this->smtpPort;

            $mail->setFrom($this->smtpUser, 'MecánicaCUT');
            $mail->addAddress($data['email'], $data['nombre']);

            $subject = $data['is_completed'] ? 
                '✅ Cita Completada - Mecánica CUT' : 
                '📅 Nueva Cita Registrada - Mecánica CUT';
            
            $mail->Subject = $subject;
            $mail->isHTML(true);
            $mail->Body = $this->buildBody($data);
            $mail->AltBody = strip_tags($this->buildBody($data));

            $mail->CharSet = 'UTF-8';
            $mail->Encoding = 'base64';

            $mail->send();
            return true;
            
        } catch (Exception $e) {
            error_log("Error al enviar correo: " . $mail->ErrorInfo);
            return false;
        }
    }

    private function buildBody($data) {
        $status = $data['is_completed'] ? '✅ Completada' : '🟡 Pendiente';
        $serviciosList = implode('', array_map(fn($s) => "<li>$s</li>", explode(', ', $data['servicios'])));
        $fechaHora = substr(str_replace('T', ' ', $data['fecha_hora']), 0, 16);
        return "
            <h2 style='color: #2c3e50;'>Detalles de la Cita</h2>
            <p><strong>Estado: </strong>$status</p>
            <p><strong>Nombre: 👤</strong> {$data['nombre']} {$data['apellido']}</p>
            <p><strong>Fecha y hora: 📅</strong> $fechaHora</p>
            <p><strong>Telefono: 📱</strong> {$data['telefono']}</p>
            <p><strong>Servicios:</strong></p>
            <ul>$serviciosList</ul>
            <p style='margin-top: 20px; color: #6c757d;'>Este es un mensaje automático, por favor no responda a este correo!!!</p>
        ";
    }
}

// Solo responde a POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['email'], $data['nombre'], $data['apellido'], $data['fecha_hora'], $data['servicios'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Datos incompletos']);
        exit;
    }

    $sender = new EmailSender();
    $ok = $sender->send($data);
    echo json_encode(['success' => $ok]);
}
