<?php
class Database {
    private $host = 'cita-db';
    private $username = 'root'; //AGREGAR NOMBRE Y CONTRASEÑA
    private $password = '2009';
    private $dbname = 'registro_citas';
    private $conn;

    public function __construct() {
        try {
            $this->conn = new PDO("mysql:host={$this->host};dbname={$this->dbname};", $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            echo("<style> h2{text-align: center; padding-top: 30px;}</style><h2>No se pueden realizar citas en este momento</h2>");
            die();
        }
    }

    public function insertCita($nombre, $apellido, $email,  $codigo_pais, $telefono, $servicios, $fecha_hora) {
        try {
            $stmt = $this->conn->prepare("INSERT INTO citas (nombre, apellido, email, codigo_pais, telefono, servicios, fecha_hora, status) 
                                          VALUES (:nombre, :apellido, :email, :codigo_pais, :telefono, :servicios, :fecha_hora,'pending')");

            $stmt->bindParam(':nombre', $nombre);
            $stmt->bindParam(':apellido', $apellido);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':codigo_pais', $codigo_pais); 
            $stmt->bindParam(':telefono', $telefono);
            $stmt->bindParam(':servicios', $servicios);
            $stmt->bindParam(':fecha_hora', $fecha_hora);

            $stmt->execute();

            return ["success" => true, "message" => "Cita registrada correctamente", "id" => $this->conn->lastInsertId()];
        } catch (PDOException $e) {
            echo "Error al registrar la cita: " . $e->getMessage(); 
            return ["success" => false, "message" => "Error al registrar la cita: " . $e->getMessage()];
        }
    }

    public function getCitas() {
        try {
            $stmt = $this->conn->prepare("SELECT * FROM citas ORDER BY fecha_hora DESC");
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC); 
        } catch (PDOException $e) {
            return ["success" => false, "message" => "Error al obtener citas: " . $e->getMessage()]; 
        }
    }
}
?>
