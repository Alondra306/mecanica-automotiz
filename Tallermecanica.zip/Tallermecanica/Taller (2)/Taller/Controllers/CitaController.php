<?php
header('Content-Type: application/json');
require_once '../Models/Conexion_db.php';

$db = new Database();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'] ?? '';
    $apellido = $_POST['apellido'] ?? '';
    $email = $_POST['email'] ?? '';
    $codigo_pais = $_POST['codigo_pais'] ?? '';
    $telefono = $_POST['telefono'] ?? '';
    $servicios = $_POST['servicios'] ?? '';
    $fecha = $_POST['fecha_hora'] ?? '';
    $fecha_hora = date('Y-m-d H:i:s', strtotime($fecha));

    if (is_array($servicios)) {
        $servicios = implode(', ', $servicios);
    }

    if (!empty($nombre) && !empty($apellido) && filter_var($email, FILTER_VALIDATE_EMAIL)&& !empty($codigo_pais)&& !empty($telefono) && !empty($servicios)&&!empty($fecha_hora)) {
        
        $response = $db->insertCita($nombre, $apellido, $email, $codigo_pais, $telefono, $servicios, $fecha_hora);
        if ($response['success']) {
            echo json_encode([
                "success" => true, 
                "message" => "Cita registrada correctamente",
                "id" => $response['id'] 
            ]);
        } else {
            echo json_encode([
                "success" => false, 
                "message" => "Error al registrar la cita: " . $response['message']
            ]);
        }
    } else {
        echo json_encode([
            "success" => false, 
            "message" => "Por favor complete todos los campos correctamente"
        ]);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $citas = $db->getCitas();
    if (isset($_GET['fecha'])) {
        $citas = array_filter($citas, function($cita) {
            return $cita['fecha'] == $_GET['fecha'];
        });
    }
    
    echo json_encode($citas);
    exit;
}

echo json_encode(["success" => false, "message" => "Solicitud no válida"]);
exit;

?>