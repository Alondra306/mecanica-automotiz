<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>MecanicaCUT</title>
<link href="css/IndexStyle.css" rel="stylesheet" type="text/css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.css">
<script src="Scripts/script1.js" defer></script>
</head>

<body>
<header role="banner" class="header">
    <div class="logo">
        <img
            src="Logo.png"
            alt="Logo"
            class="logo-img"
        />
    </div>
    <nav class="navbar">
        <ul>
        <li><a>Inicio</a></li>
        <li><a href="#productos">Productos</a></li>
        <li><a href="#servicios">Servicios</a></li>
        <li><a href="#registro-cita" class="cita">Crear Cita</a></li>
        </ul>
    </nav>
</header>

<section id="productos">
    <h2>Productos</h2>
    <div class="producto-list">
        <article class="producto">
            <img src="css/imagenes/suspension.jpg">
            <h3>Suspensiones</h3>
        </article>
        <article class="producto">
            <img src="css/imagenes/llantas.jpg">
            <h3>Llantas</h3>
        </article>
        <article class="producto">
            <img src="css/imagenes/aceite.jpg">
            <h3>Aceite</h3>
        </article>
        <article class="producto">
            <img src="css/imagenes/bateria.jpeg">
            <h3>Batería para Autos</h3>
        </article>
        <article class="producto">
            <img src="css/imagenes/jump.jpg">
            <h3>Cables para corriente</h3>
        </article>
        <article class="producto">
            <img src="css/imagenes/kit.jpg">
            <h3>Kit de Limpieza</h3>
        </article>
        <article class="producto">
            <img src="css/imagenes/caralarm.png">
            <h3>Alarma de Coche</h3>
        </article>
        <article class="producto">
            <img src="css/imagenes/tapete.jpg">
            <h3>Tapetes para Coche</h3>
        </article>
        <article class="producto">
            <img src="css/imagenes/cera.jpg">
            <h3>Cera para Coche</h3>
        </article>
    </div>
</section>

<section id="servicios">
    <h2>Servicios</h2>
    <div class="servicios-container">
        <div class="about-card">
            <h3>Cambio de Aceite</h3>
            <p>
                Cambio de Aceite para prevenir desgaste entre las piezas del motor <br><br><br>
            </p>
            <img src="css/imagenes/oilchange.png" class="bottom-image">
        </div>
        <div class="about-card">
            <h3>Revisiones</h3>
            <p>
                Queremos ofrecer revisiones a nuestros clientes para prevenir desgastes y cuidar el estado de su vehículo <br><br>
            </p>
            <img src="css/imagenes/repair.jpg" class="bottom-image">
        </div>
        <div class="about-card">
            <h3>Mantenimiento</h3>
            <p>
                Realizar revisión para tener un panorama más claro sobre el estado de tu vehículo y planificar los próximos servicios antes de presentar una falla
            </p>
            <img src="css/imagenes/carmain.png" class="bottom-image" />
        </div>
    </div>
</section>

<!-- Registro de Cita -->
<?php include '../Models/Conexion_db.php';
    $db= new Database();
?>
<section id="registro-cita">
    <h2>Registro de citas</h2>
    <div class="container">

        <form class="registroDeCitas" method="post">

            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" required><br>

            <label for="apellido">Apellido:</label>
            <input type="text" id="apellido" name="apellido" required><br>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required><br>

            <label for="telefono">Teléfono:</label>
            <input type="tel" id="telefono" name="telefono" required><br>
            <input type="hidden" name="codigo_pais" id="codigo_pais">

            <label for="servicio">Servicios:</label>
            <div class="accordion">
                <div class="accordion-item">
                    <button type="button" class="accordion-header btn-acordeon" onclick="toggleAcordeon(this,'mantenimiento')">Mantenimiento  <span class="arrow">⌄</span> </button>
                    <div id="contenido-mantenimiento" class="accordion-content" style="display:none;">
                        <label><input type="checkbox" name="servicios[]" value="limpieza-filtro-aire"> Limpieza de Filtro de Aire</label><br>
                        <label><input type="checkbox" name="servicios[]" value="limpieza-gasolina"> Limpieza de Gasolina</label>
                        <label><input type="checkbox" name="servicios[]" value="limpieza-bujias"> Limpieza de Bujías</label>
                        <label><input type="checkbox" name="servicios[]" value="nivelar-bateria"> Nivelar la batería</label>
                        <label><input type="checkbox" name="servicios[]" value="rotacion-llantas"> Rotación de llantas</label>
                    </div>
                </div>
                <div class="accordion-item">
                    <button type="button" class="accordion-header btn-acordeon" onclick="toggleAcordeon(this,'revisiones')">Revisiones <span class="arrow" >⌄</span> </button>
                    <div id="contenido-revisiones" class="accordion-content" style="display:none;">
                        <label><input type="checkbox" name="servicios[]" value="reparacion-frenos"> Reparación de Frenos</label><br>
                        <label><input type="checkbox" name="servicios[]" value="reparacion-motor"> Reparación de Motor</label>
                        <label><input type="checkbox" name="servicios[]" value="revision-luces"> Revisión de Luces</label>
                        <label><input type="checkbox" name="servicios[]" value="revision-suspension"> Revisión de Suspensión</label>
                        <label><input type="checkbox" name="servicios[]" value="revision-sistema-escape"> Revisión de Sistema de Escape</label>     
                        <label><input type="checkbox" name="servicios[]" value="niveles-liquidos"> Revisión de niveles de líquidos</label>                                                                   
                    </div>
                </div>
                <div class="accordion-item">
                    <button type="button" class="accordion-header btn-acordeon" onclick="toggleAcordeon(this,'cambio-aceite')">Cambio de Aceite <span class="arrow">⌄</span> </button>
                    <div id="contenido-cambio-aceite" class="accordion-content" style="display:none;">
                        <label><input type="checkbox" name="servicios[]" value="cambio-aceite"> Cambio de Aceite</label><br>
                    </div>
                </div>
            </div><br>

            <!-- Este campo oculto contendrá los valores seleccionados  <input type="hidden" id="servicios-seleccionados" name="servicios"> -->

            <label for="fecha-hora">Selecciona fecha y hora:</label>
            <input type="datetime-local" id="fecha-hora" name="fecha_hora" required><br>

            <button type="submit" name="Registro" >Registrarse</button>
        </form>
    </div>
</section>

<!-- Script para preparar el campo oculto -->
<script>
    function validarServicios() {
        var checkboxes = document.querySelectorAll('input[name="servicios[]"]:checked');
        if (checkboxes.length === 0) {
            alert("Por favor, selecciona al menos un servicio antes de registrarte.");
            return false; 
        }
        return true; 
    }

    $(document).ready(function(){
        $(".registroDeCitas").submit(function(event){
            event.preventDefault(); 
            if(validarServicios()){
                var formData=$(this).serialize();
                console.log("Form data: ", formData);
                $.ajax({
                    type: "POST",
                    url: "../Controllers/CitaController.php",
                    data: formData,
                    dataType: "json",
                    success: function(response){
                        console.log("Response from server: ", response);
                        if(response.success){
                            alert("Cita registrada"); 
                            $(".registroDeCitas")[0].reset();
                        }else{
                            alert("Error al registrar cita")
                        }
                    },
                    error: function(xhr, status, error){
                        console.log("AJAX error:", xhr.responseText);
                        alert("Failed to send request. Check network or server.");
                    }
                });
            }else{
                alert("ERROR");
            }

        });
    });
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const phoneInput = document.querySelector("#telefono");
        const iti = window.intlTelInput(phoneInput, {
            initialCountry: "mx",
            preferredCountries: ["mx", "us", "es", "co", "ar", "br", "cl"],
            separateDialCode: true,
            utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js"
        });
        phoneInput.addEventListener("countrychange", function() {
            document.querySelector("#codigo_pais").value = iti.getSelectedCountryData().dialCode;
        });
        document.querySelector("#codigo_pais").value = iti.getSelectedCountryData().dialCode;
        
    });
</script>
</body>
</html>