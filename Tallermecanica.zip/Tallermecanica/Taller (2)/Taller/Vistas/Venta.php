<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<title>Ventas</title>

<style>
        body { background-color: #0A2740; color: #FFF; font-family: Arial, sans-serif; }
        .container { width: 80%; margin: auto; padding: 20px; background: #164673; border-radius: 10px; }
        table { width: 100%; border-collapse: collapse; background: #FFF; color: #000; }
        th, td { padding: 10px; border: 1px solid #000; text-align: center; }
        .button { padding: 10px; margin: 5px; background: #bde2f1; border: none; cursor: pointer; }
        .button:hover { background: #CCC; }
    </style>
    
</head>

<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Mecanica</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Home</a></li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Citas<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="#">Crear Cita</a></li>
          <li><a href="#">Ver Cita</a></li>
        </ul>
      </li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Productos<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="#">Productos</a></li>
        </ul>
      </li>
      <li><a href="#">Ventas</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
  </div>
</nav>
  
 <div class="container">
        <h2>Mecanica</h2>
        <form>
            <label>Producto:</label>
            <select name="producto">
                <option value="pila">Pila</option>
                <option value="aceite">Aceite</option>
            </select>
            <label>Num. Ticket: 10001</label>
            <label>Fecha: 16/2/2025</label>
            <br><br>
            <label>Precio:</label>
            <input type="text" name="precio">
            <label>Cantidad:</label>
            <input type="number" name="cantidad" value="0">
            <button type="submit" class="button">Actualizar</button>
        </form>
        <br>
        <table>
            <tr>
                <th>Num.</th>
                <th>Nombre</th>
                <th>Cantidad</th>
                <th>$ Unidad</th>
                <th>Total</th>
            </tr>
            <tr>
                <td>1</td>
                <td>Pila</td>
                <td>1</td>
                <td>500</td>
                <td>500</td>
            </tr>
        </table>
        <br>
        <label>Total: 500.0</label>
        <br><br>
        <button class="button">Reportes</button>
        <button class="button">Eliminar</button>
        <button class="button">Cancelar</button>
        <button class="button">Comprar</button>
    </div>

</body>
</html>