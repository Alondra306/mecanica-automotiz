<?php
require_once 'Models/Conexion_db.php';

$db = new Database();
// Test de inserción lo dejo por si las dudonchas 
$result = $db->insertCita(
    "Ana", 
    "Pérez", 
    "ana@example.com", 
    "52", 
    "5512345678", 
    "Limpieza de bujías, Rotación de llantas", 
    date('Y-m-d H:i:s', strtotime('+1 day'))
);
print_r($result);

// Test de consulta
print_r($db->getCitas());
?>