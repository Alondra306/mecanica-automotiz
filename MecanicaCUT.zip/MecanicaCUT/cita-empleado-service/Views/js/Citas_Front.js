let appointments = [];
let currentEditingId = null;
let currentView = 'month';
let currentDate = new Date();


document.addEventListener('DOMContentLoaded', () => {
    fetchAppointments();
    showView(currentView);
    document.getElementById('appointmentForm').addEventListener('submit', handleFormSubmit);
    setupDateTimeInput();
    cargarServicios();
});


function fetchAppointments() {
    fetch('/Controller/API_Controller.php')
        .then(response => {
            if (!response.ok) {
                throw new Error(`Error HTTP ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            let citasData = [];
            
            if (Array.isArray(data)) {
                citasData = data;
            } else if (data && Array.isArray(data.data)) {
                citasData = data.data;
            } else {
                throw new Error('Formato de respuesta no reconocido');
            }
            appointments = citasData.map(app => ({
                ...app,
                id: app.id.toString(),
                status: app.status || 'pending',
                fecha_hora: app.fecha_hora ? app.fecha_hora.replace(' ', 'T') : null,
                servicios: app.servicios || '',
                time: app.fecha_hora ? app.fecha_hora.split('T')[1].substring(0, 5) : ''
            }));
            
            showView(currentView);
        })
        .catch(error => {
            console.error('Error al obtener citas:', error);
            showNotification('Error al cargar citas: ' + error.message, 'error');
            appointments = [];
            showView(currentView);
        });
}

async function postAppointment(formData) {
    const url = '/Controller/API_Controller.php';
    const method = formData.id ? 'PUT' : 'POST'; 

    fetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
    })
    .then(async response => {
        const text = await response.text();
        try {
            const data = text ? JSON.parse(text) : {};
            if (!response.ok) {
                console.error('Error del servidor:', data);
                throw new Error(data.error || `Error ${response.status}: ${response.statusText}`);
            }
            return data;
        } catch (e) {
            console.error('Error parseando respuesta:', text);
            throw new Error(text || 'Error desconocido');
        }
    })
    .then(data => {
       /////////////////////////// 
        enviarCorreoCita(formData, false);
        ///////////////////////////////
        showNotification(formData.id ? 'Cita actualizada!' : 'Cita guardada!');
        fetchAppointments();
        hideModal();
    })
    .catch(err => {
        console.error('Error:', err);
        showNotification(`${err.message}`, 'error');
    });
}

async function cargarServicios() {
    try {
        const response = await fetch('http://localhost:8023/Controllers/ServiceController.php');
   
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        
        if (Array.isArray(data)) {
            const serviciosContainer = document.getElementById('servicios-container');
            const existingButton = serviciosContainer.querySelector('.accordion-header');
            serviciosContainer.innerHTML = '';
            if (existingButton) {
                serviciosContainer.appendChild(existingButton);
            }
            
            const contentDiv = document.createElement('div');
            contentDiv.className = 'accordion-content';
            contentDiv.style.display = 'none';
            contentDiv.id = 'contenido-mantenimiento';
            
            data.forEach(servicio => {
                const checkboxDiv = document.createElement('div');
                checkboxDiv.className = 'form-check';
                
                checkboxDiv.innerHTML = `
                    <label class="form-check-label" for="servicio-${servicio.ID}">
                    <input class="form-check-input" type="checkbox" 
                           name="servicio" 
                           value="${servicio.ID}" 
                           id="servicio-${servicio.ID}"
                           data-precio="${servicio.ServicePrice}"
                           data-nombre="${servicio.ServiceName}">
                    ${servicio.ServiceName}</label>
                `;
                
                contentDiv.appendChild(checkboxDiv);
            });
            
            serviciosContainer.appendChild(contentDiv);
            const accordionButton = serviciosContainer.querySelector('.accordion-header');
            if (accordionButton) {
                accordionButton.onclick = function() {
                    toggleAcordeon(this, 'mantenimiento');
                };
            }
        }
    } catch (error) {
        console.error('Error cargando servicios:', error);
        showNotification('Error al cargar servicios: ' + error.message, 'error');
    }
}

async function handleFormSubmit(e) {
    e.preventDefault();

    const checkboxes = document.querySelectorAll('input[name="servicio"]:checked');
    if (checkboxes.length === 0) {
        showNotification('Por favor, selecciona al menos un servicio', 'error');
        return;
    }

    const nombreServicios = Array.from(checkboxes).map(cb => cb.dataset.nombre);
    document.getElementById('servicios-seleccionados').value = nombreServicios.join(', ');


    const formElements = e.target.elements;
    const formData = {
        nombre: formElements.nombre.value,
        apellido: formElements.apellido.value,
        email: formElements.email.value,
        codigo_pais: formElements.codigo_pais.value,
        telefono: formElements.telefono.value,
        servicios: document.getElementById('servicios-seleccionados').value,
        fecha_hora: formElements.fecha_hora.value
    };

    const errors = validateForm(formData);
    if (errors.length > 0) {
        showNotification(errors.join('<br>'), 'error');
        return;
    }

    const isAvailable = await checkAppointmentAvailability(formData.fecha_hora, currentEditingId || null);
    if (!isAvailable) {
        showNotification('Ya existe una cita programada dentro de 1 hora antes o despus de este horario', 'error');
        return;
    }

    if (currentEditingId) formData.id = currentEditingId;

    postAppointment(formData);
}

function validateForm(formData) {
    const errors = [];
    const currentDate = new Date();
    const selectedDate = new Date(formData.fecha_hora);
    const hora = formData.fecha_hora.split('T')[1];

    if (!formData.fecha_hora) errors.push('Fecha y hora requeridas');
    if (hora < '08:00:00') errors.push('Horario no permitido (08:00 a.m. y 08:00 p.m.)');
    if (hora > '19:00:00') errors.push('Cerramos a la 08:00 p.m. agenda minimo 1 hora antes');
    if (selectedDate < currentDate) errors.push('No se pueden agendar citas en el pasado');
    if (!formData.nombre.trim() || !formData.apellido.trim()) errors.push('Nombre y apellido del cliente requerido');
    if (!formData.servicios || formData.servicios.trim() === '') errors.push('Debe seleccionar al menos un servicio');
    if (!formData.telefono.trim() || formData.telefono.length < 10) errors.push('Telefono valido requerido');

    return errors;
}

async function checkAppointmentAvailability(dateTime, excludeId = null) {
    try {
        const startTime = new Date(dateTime);
        startTime.setHours(startTime.getHours() - 1);
        
        const endTime = new Date(dateTime);
        endTime.setHours(endTime.getHours() + 1);
        
        let url = `/Controller/API_Controller.php?start=${startTime.toISOString()}&end=${endTime.toISOString()}`;
        
        if (excludeId) {
            url += `&exclude=${excludeId}`;
        }

        const response = await fetch(url);
        const data = await response.json();

        if (!response.ok) {
            throw new Error('Error al verificar disponibilidad');
        }
        
        
        return data.count === 0;
    } catch (error) {
        console.error('Error checking availability:', error);
        return false;
    }
}

function changeMonth(offset) {
    currentDate.setMonth(currentDate.getMonth() + offset);
    generateCalendar(currentDate);
}

function generateCalendar(date) {
    const calendarView = document.getElementById('calendarView');
    calendarView.innerHTML = '';
    
    const monthNames = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 
                       'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
    const daysOfWeek = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];

    const headerHTML = `
    <div class="calendar-nav">
        <button class="btn btn-flex" onclick="changeMonth(-1)"><</button>
        <h2>${monthNames[date.getMonth()]} ${date.getFullYear()}</h2>
        <button class="btn btn-flex" onclick="changeMonth(1)">></button>
    </div>
`;

    let calendarGridHTML = '<div class="calendar-grid">';
    calendarGridHTML += daysOfWeek.map(day => `<div class="calendar-header">${day}</div>`).join('');
    
    let day = new Date(date);
    day.setDate(1);
    day.setDate(day.getDate() - day.getDay());
    
    for(let i = 0; i < 42; i++) {
        const isOtherMonth = day.getMonth() !== date.getMonth();
        const isToday = day.toDateString() === new Date().toDateString();
        calendarGridHTML += `
            <div class="calendar-day ${isOtherMonth ? 'other-month' : ''} ${isToday ? 'current-day' : ''}">
                <strong>${day.getDate()}</strong>
                ${renderDailyAppointments(day)}
            </div>
        `;
        day.setDate(day.getDate() + 1);
    }
    
    calendarGridHTML += '</div>';
    calendarView.innerHTML = headerHTML + calendarGridHTML;
}

function generateWeekView() {
    const today = new Date();
    const startOfWeek = new Date(today);
    startOfWeek.setDate(today.getDate() - today.getDay());
    
    const calendarView = document.getElementById('calendarView');
    calendarView.innerHTML = '';
    
    for(let i = 0; i < 7; i++) {
        const currentDay = new Date(startOfWeek);
        currentDay.setDate(startOfWeek.getDate() + i);
        calendarView.innerHTML += `
            <div class="week-day">
                <h3>${currentDay.toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric' })}</h3>
                ${renderDailyAppointments(currentDay)}
            </div>
        `;
    }
    calendarView.innerHTML += '</div>';
}


function generateDayView(selectedDate = new Date()) {
    const calendarView = document.getElementById('calendarView');
    calendarView.innerHTML = `
        <div class="day-view">
            <button class="btn btn-primary" onclick="showView('month')">← Volver</button>
            <h2>${selectedDate.toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' })}</h2>
            ${renderDailyAppointments(selectedDate)}
        </div>
    `;
}

function parseDBDate(dateString) {
    if (!dateString) return null;
    try {
        const isoString = dateString.includes('T') ? dateString : dateString.replace(' ', 'T');
        const date = new Date(isoString);
        if (isNaN(date.getTime())){
            throw new Error('Fecha invalida');
        }
        return date;
    }catch (e){
        console.error('Error al parsear fecha:', dateString, e);
        return null;
    }
}

function renderDailyAppointments(date) {
    const dayString = date.toDateString();
    const dailyAppointments = appointments.filter(app => {
        try {
            if (!app.fecha_hora) return false;
            const appDate = parseDBDate(app.fecha_hora);
            return appDate.toDateString() === dayString;
        } catch (e) {
            console.error('Error parsing date:', app, e);
            return false;
        }
    });

    const formatServiceName = (service) => {
        if (!service) return 'Sin servicio';
        return service.split(',')
            .map(part => part.trim()
                .split('-')
                .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
                )
            .join(' ')
        )
        .join(' | ');
    };
    
    if(currentView === 'month'){
        return dailyAppointments.map(app => {
            const serviceName = formatServiceName(app.servicios);
            return `<div class="appointment-card mini-card ${date.getMonth() !== currentDate.getMonth() ? 'no-click' : ''}
                ${app.status === 'completed' ? 'completed' : ''}" 
                ${date.getMonth() === currentDate.getMonth() ? `onclick="showAppointmentDetails('${app.id}')"` : ''}>
                <small>${serviceName}</small>
            <small>${app.fecha_hora?.split('T')[1]?.substring(0,5)  || ''}</small>
            </div>
        `}).join('');
    }else{
        return dailyAppointments.map(app => {
            const serviceName = formatServiceName(app.servicios);
            return `<div class="appointment-card mini-card
                ${app.status === 'completed' ? 'completed' : ''}" onclick="showAppointmentDetails('${app.id}')">
                <small>${serviceName}</small>
                <small>${app.fecha_hora?.split('T')[1]?.substring(0,5) || ''}</small>
            </div>
        `}).join('');
    }
}

function showNotification(message, type = 'success') {
    const notification = document.getElementById('notification');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = message;
    notification.style.display = 'block';
    setTimeout(() => {
        notification.style.display = 'none';
    }, 5000);
}

function editAppointment(id) {
    const appointment = appointments.find(a => a.id == id);
    if (appointment) {
        currentEditingId = id;
        const modal = document.getElementById('newAppointmentModal');
        const form = modal.querySelector('form');

        if (form) {
            form.elements.nombre.value = appointment.nombre || '';
            form.elements.apellido.value = appointment.apellido || '';
            form.elements.email.value = appointment.email || '';
            form.elements.codigo_pais.value = appointment.codigo_pais || '';
            form.elements.telefono.value = appointment.telefono || '';
            
            const servicios = appointment.servicios ? 
                (Array.isArray(appointment.servicios) ? 
                    appointment.servicios : 
                    appointment.servicios.split(', ')) : [];
            
            document.querySelectorAll('input[name="servicio"]').forEach(cb => {
                cb.checked = false;
            });

            const allCheckboxes = document.querySelectorAll('input[name="servicio"]');
            
            servicios.forEach(serviciosNombre => {

                const checkbox = Array.from(allCheckboxes).find(cb => cb.dataset.nombre === serviciosNombre.trim());
                if (checkbox) checkbox.checked = true;
            });
            
            form.elements.fecha_hora.value = appointment.fecha_hora || '';
            
            showModal();
        } else {
            console.error('Formulario no encontrado');
            showNotification('No se pudo cargar el formulario', 'error');
        }
    } else {
        console.error('No se encontró la cita con ID:', id);
        showNotification('No se pudo cargar la cita para editar', 'error');
    }
}

function cancelAppointment(id) {    
    fetch(`/Controller/API_Controller.php?id=${id}`, {
        method: 'DELETE'
    })
    .then(async res => {
        if (!res.ok) {
            const errorData = await res.json();
            throw new Error(errorData.error || `Error ${res.status}`);
        }
        return res.json();
    })
    .then(() => {
        fetchAppointments();
        showNotification('Cita cancelada');
        hideModal();
    })
    .catch(err => {
        console.error('Error:', err);
        showNotification(`Error al cancelar cita: ${err.message}`, 'error');
    });
}

function completeAppointment(id) {
    const serviciosContainer = document.getElementById('servicios-container');
    if (!serviciosContainer) {
        showNotification('Error: No se pudo cargar la sección de servicios', 'error');
        return;
    }

    const contenido = serviciosContainer.querySelector('.accordion-content');
    if (contenido) contenido.style.display = 'block';

    const appointment = appointments.find(a => a.id == id);
    if (!appointment) {
        showNotification('No se encontró la cita', 'error');
        if (contenido) contenido.style.display = 'none';
        return;
    }

    let serviciosNombres = [];
    if (appointment.servicios) {
        serviciosNombres = Array.isArray(appointment.servicios) 
            ? appointment.servicios 
            : appointment.servicios.split(',').map(s => s.trim());
    }

    const checkboxes = serviciosContainer.querySelectorAll('input[name="servicio"]');
    checkboxes.forEach(cb => {
        const nombreServicio = cb.dataset?.nombre?.trim() || '';
        cb.checked = serviciosNombres.some(nombre => nombre.trim() === nombreServicio);
    });

    const selectedCheckboxes = serviciosContainer.querySelectorAll('input[name="servicio"]:checked');
    const serviciosIds = Array.from(selectedCheckboxes).map(cb => cb.value);

    if (serviciosIds.length === 0) {
        showNotification('No se encontraron servicios para esta cita', 'error');
        if (contenido) contenido.style.display = 'none';
        return;
    }

    fetch('/Controller/API_Controller.php', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: id })
    })
    .then(async res => {
        if (!res.ok) {
            const errorData = await res.json();
            throw new Error(errorData.error || `Error ${res.status}`);
        }
        return res.json();
    })
    .then(() => {  
        appointment.servicios = serviciosNombres;
        ////////////////////////
        enviarCorreoCita(appointment, true);
        /////////////////////
        console.log(serviciosIds);
        showNotification('Cita marcada como completada');
        fetchAppointments();
        hideModal();

        setTimeout(() => {
            const params = new URLSearchParams();
            params.append('cita_id', id);
            //////////////////
            params.append('mail', appointment.email);
            /////////////////
            serviciosIds.forEach(id => params.append('servicio_id[]', id));
            
            window.location.href = `http://localhost:8022/Views/Venta.php?${params.toString()}`;
        }, 600);
    })
    .catch(err => {
        console.error('Error:', err);
        showNotification(`Error: ${err.message}`, 'error');
    });
}

function showView(view) {
    currentView = view;
    const calendarView = document.getElementById('calendarView');
    calendarView.className = `calendar-view ${view}-view`;
    
    switch(view) {
        case 'month':
            generateCalendar(currentDate);
            break;
        case 'week':
            generateWeekView();
            break;
        case 'day':
            generateDayView(new Date());
            break;
    }
}

function filterAppointments() {
    const filter = document.getElementById('filterSelect').value;

    if(filter === 'all'){
        showView('month')
    }else{
        const filtered = appointments.filter(app => app.status === filter);
        renderFilteredAppointments(filtered);
    }
}

function renderFilteredAppointments(filteredApps) {
    const container = document.getElementById('calendarView');
    const formatServiceName = (service) => {
        if (!service) return 'Sin servicio';
        return service.split(',').map(part => 
                part.trim().split('-').map(word => 
                    word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
                    )
                .join(' ')
            )
            .join(' | ');
    };
    container.innerHTML = filteredApps.map(app => {
        const serviceName = formatServiceName(app.servicios);
        return `
        <div class="appointment-card ${app.status}">
            <h3>${serviceName}</h3>
            <ul class="appointment-details">
                <li>📅 Fecha: ${app.fecha_hora?.split('T')[0] || 'No especificada'}</li>
                <li>⏰ Hora: ${app.fecha_hora?.split('T')[1]?.substring(0, 5) || 'No especificada'}</li>
                <li>👤 Cliente: ${app.nombre || ''} ${app.apellido || ''}</li>
                <li>📧 Email: ${app.email}</li>
                <li>📱 Telefono: ${app.telefono}</li>
                <li>🚗 Servicio: ${serviceName}</li>
                <li>🏷️ <span class="status-badge status-${app.status}">${app.status}</span></li>
            </ul>
            ${app.status !== 'completed' ? 
                `<button class="btn btn-primary" onclick="editAppointment('${app.id}')">Editar</button>
                <button class="btn btn-success" onclick="completeAppointment('${app.id}')">Finalizar</button>
                <button class="btn btn-danger" onclick="cancelAppointment('${app.id}')">Cancelar</button>` : ''}
                
        </div>
    `}).join('');
}


function showAppointmentDetails(id) {
    const numericId = typeof id === 'string' ? parseInt(id) : id;
    const appointment = appointments.find(a => a.id == numericId);
    if (!appointment) {
        console.error('Cita no encontrada con ID:', id, 'Citas disponibles:', appointments);
        showNotification('No se pudo encontrar la cita', 'error');
        return;
    }

    const modalTitle = document.getElementById('modalTitle');
    const appointmentsList = document.getElementById('dailyAppointmentsList');
    
    if (!modalTitle || !appointmentsList) {
        console.error('Elementos del modal no encontrados');
        return;
    }
    
    modalTitle.textContent = `Cita`;

    const formatServiceName = (service) => {
        if (!service) return 'Sin servicio';
        return service.split(',').map(part => 
                part.trim().split('-').map(word => 
                    word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
                    )
                .join(' ')
            )
            .join(' | ');
    };
    const serviceName = formatServiceName(appointment.servicios);
    appointmentsList.innerHTML = `
        <div class="appointment-card ${appointment.status === 'completed' ? 'completed' : ''}">
            <h3>${serviceName}</h3>
            <ul class="appointment-details">
                <li>📅 Fecha: ${appointment.fecha_hora?.split('T')[0] || 'No especificada'}</li>
                <li>⏰ Hora: ${appointment.fecha_hora?.split('T')[1]?.substring(0, 5) || 'No especificada'}</li>
                <li>👤 Cliente: ${appointment.nombre || ''} ${appointment.apellido || ''}</li>
                <li>📧 Email: ${appointment.email || 'No especificado'}</li>
                <li>📱 Teléfono: ${appointment.telefono || 'No especificado'}</li>
            </ul>
            <p>Estado: <span class="status-badge status-${appointment.status || 'pending'}">${appointment.status || 'pending'}</span></p>
            ${appointment.status !== 'completed' ? 
                `<button class="btn btn-primary" onclick="editAppointment('${appointment.id}')">Editar</button>
                <button class="btn btn-success" onclick="completeAppointment('${appointment.id}')">Finalizar</button>
                <button class="btn btn-danger" onclick="cancelAppointment('${appointment.id}')">Cancelar</button>` : ''}
        </div>
    `;
    
    document.getElementById('dailyAppointmentsModal').style.display = 'flex';
}

function showModal() {
    document.getElementById('newAppointmentModal').style.display = 'flex';
}

function hideModal() {
    document.getElementById('appointmentForm').reset();
    currentEditingId = null;
    document.getElementById('newAppointmentModal').style.display = 'none';
    document.getElementById('dailyAppointmentsModal').style.display = 'none';
}

window.onclick = function(event) {
    if (event.target.className === 'modal') {
        hideModal();
    }
}

function setupDateTimeInput() {
    const dateTimeInput = document.getElementById('fecha-hora');
    
    dateTimeInput.addEventListener('change', async function() {
        const selectedDateTime = this.value;
        if (!selectedDateTime) return;
        
        const isAvailable = await checkAppointmentAvailability(selectedDateTime, currentEditingId || null);
        if (!isAvailable) {
            showNotification('Este horario no está disponible (debe haber al menos 1 hora entre citas)', 'error');
            this.value = '';
        }
    });
}

function toggleAcordeon(boton, categoria) {
    var contenido = document.getElementById("contenido-" + categoria);
    var flecha = boton.querySelector(".arrow");

    if (!contenido || !flecha) return;

    if (contenido.style.display === "none" || contenido.style.display === "") {
        contenido.style.display = "block";
        boton.classList.add("activo");
        flecha.innerHTML = "⌃";
    } else {
        contenido.style.display = "none";
        boton.classList.remove("activo");
        flecha.innerHTML = "⌄";
    }
}

function enviarCorreoCita(data, isFinalizada) {
    const serviciosTexto = Array.isArray(data.servicios) ? data.servicios.join(', ') : data.servicios;

    fetch('../Controller/EmailController.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: isFinalizada ? 'complete_appointment' : 'new_appointment',
            nombre: data.nombre,
            apellido: data.apellido,
            email: data.email,
            fecha_hora: data.fecha_hora,
            telefono: data.telefono,
            servicios: serviciosTexto,
            is_completed: isFinalizada
        })
    })
    .then(async res => {
        const text = await res.text();
        console.log('🟡 Respuesta cruda del servidor:', text);
        try {
            const json = JSON.parse(text);
            if (json.success) {
                showNotification('Correo Enviado!!', 'success');
            } else {
                showNotification(json.message || 'Error al enviar el correo', 'error');
            }
        } catch (e) {
            console.error('❌ Error de parseo JSON:', text);
            if (res.ok) {
                showNotification('Correo Enviado!!', 'success');
            } else {
                showNotification('Error en el formato de respuesta', 'error');
            }
        }
    })
    .catch(error => {
        console.error('❌ Error al enviar correo:', error);
        showNotification('No se pudo enviar el correo', 'error');
    });
    
}
