<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>MecanicaCUT</title>
<link href="HomeStyle.css" rel="stylesheet" type="text/css"> 
</head>

<body>

<header role="banner" class="header">
      <div class="logo">
          <img
            src="Logo.png"
            alt="Logo"
            class="logo-img"
          />
      </div>
      <nav class="navbar">
        <ul>
          <li><a href="http://localhost:8020/Views/citas.php">Inicio</a></li>
            <li class="dropdown">
          	<a class="dropbtn" href="http://localhost:8020/Views/citas.php">Citas<span class="caret"></span></a>
            </li>
           <li class="dropdown">
          	<a class="dropbtn">Ventas<span class="caret"></span></a>
          	<div class="dropdown-content">
          		<a href="http://localhost:8022/Views/Venta.php">Hacer Venta</a>
          	</div>
          </li>
          <li><a href="http://localhost:8023/Views/productos.php">Inventario</a></li>
          <li><a href="http://localhost:8010/login">Logout</a></li>
        </ul>
      </nav>
    </header>
    

</body>
</html>