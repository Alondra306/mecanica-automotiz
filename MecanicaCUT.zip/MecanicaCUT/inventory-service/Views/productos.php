<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<title>MecanicaCUT</title>

<link href="ProductoStyle.css" rel="stylesheet" type="text/css"> 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <div class="c">
        <?php include 'header.php';?>
        <?php include __DIR__ . '/../Models/ProductoModel.php';
            $db = new Database();
            $services= $db->getServices();
            $products = $db->getProducts();
        ?>
        <div class="container">
            <div class="global">
                <div class="tab">
                    <button class="tablinks" onclick="openTab(event, 'Productos')" id="defaultOpen">Productos</button>
                    <button class="tablinks" onclick="openTab(event, 'Servicios')">Servicios</button>
                </div>
                <div id="Productos" class="tabcontent">
                    <form method="POST" class="addProducto">
                    <h3>AGREGAR PRODUCTO</h3>
                    <input class="txt" type="text" name="nombreProducto"placeholder="Agregar nombre Producto" required>
                    <input class="txt" type="number" name="cantidad" min="1" placeholder="Agregar cantidad" required>
                    <input class="txt" type="number" name="precio" placeholder="Agregar precio" min="0" required>
                    <input type="submit" value="Agregar Producto"  name="agregarProducto" class="btnAgregar">
                    </form>

                    <div class="tablecontainer">
                        <table class="tableProductos">
                            <thead>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Cantidad</th>
                                <th>Precio</th>
                            </thead>
                            <tbody id="tableProductos">
                                <?php if (!empty($products)) : ?>
                                    <?php foreach ($products as $row) : ?>
                                        <tr>
                                            <td><?= htmlspecialchars($row['ID']) ?></td>
                                            <td><?= htmlspecialchars($row['PRODNOMBRE']) ?></td>
                                            <td><?= htmlspecialchars($row['STOCK']) ?></td>
                                            <td>$<?= htmlspecialchars($row['PRECIOUNI']) ?></td>
                                            <td class="action">
                                                <a data-id="<?= htmlspecialchars($row['ID']) ?>" class="removeProd"><i class="fa fa-trash"></i> Eliminar</a>
                                                <input id="actualizarProductos" class="update" type="submit" value="update" name="updateBtn">
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else : ?>
                                    <tr><td colspan="5"><span>No products added</span></td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div id="Servicios" class="tabcontent">
                    <form  method="post" class="addService" >
                        <h3>AGREGAR SERVICIO</h3>
                        <input class="txt" type="text" name="nombreServicio"placeholder="Agregar nombre Servicio" required>
                        <input class="txt" type="number" name="precioServicio" placeholder="Agregar precio" min="0" required>
                        <input type="submit" value="Agregar Servicio"  name="agregarServicio" class="btnAgregar">
                    </form>

                    <div class="tablecontainer">
                        <table class="tableServicios">
                            <thead>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Precio</th>
                            </thead>
                            <tbody id="tableServicios">
                            <?php if (!empty($services)) : ?>
                                    <?php foreach ($services as $row) : ?>
                                        <tr>
                                            <td><?= htmlspecialchars($row['ID']) ?></td>
                                            <td><?= htmlspecialchars($row['ServiceName']) ?></td>
                                            <td><?= htmlspecialchars($row['ServicePrice']) ?></td>
                                            <td class="action">
                                                <a data-id="<?= htmlspecialchars($row['ID']) ?>" class="removeServ"><i class="fa fa-trash"></i> Eliminar</a>
                                                <input id="actualizarServicios" class="update" type="submit" value="update" name="updateBtn">
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else : ?>
                                    <tr><td colspan="5"><span>No services added</span></td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div id="updateModal" class="modal">
            <div class="modal-content">
                <span class="close">&times;</span>
                <h3>Actualizar Producto</h3>
                <form id="updateForm" class="updateWindow">
                    <input type="hidden" name="id" id="updateId">
                    <label>Producto</label>
                    <input type="text" name="nombreProducto" id="updateNombre" placeholder="Nombre del producto" required>
                    <label>Stock/Cantidad</label>
                    <input type="number" name="cantidad" id="updateCantidad" min="1" placeholder="Cantidad" required>
                    <label>Precio</label>
                    <input type="number" name="precio" id="updatePrecio" min="0" placeholder="Precio" required>
                    <input id="ProdUpdateButton" type="submit" value="Actualizar" class="btnActualizar">
                </form>
            </div>
        </div>
        <div id="upServicePopUp" class="modal">
            <div class="modal-content">
                <span class="close">&times;</span>
                <h3>Actualizar Servicios</h3>
                <form id="updateServiceForm" class="updateWindow">
                    <input type="hidden" name="id" id="upServId">
                    <label>Servicio</label>
                    <input type="text" name="nombreProducto" id="upServName" placeholder="Nombre del producto" required>
                    <label>Precio</label>
                    <input type="number" name="precio" id="upPrice" min="0" placeholder="Precio" required>
                    <input id="UpdateButton" type="submit" value="Actualizar" class="btnActualizar">
                </form>
            </div>
        </div>
    </div>
    <script>
        function openTab(evt, tabName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(tabName).style.display = "block";
        evt.currentTarget.className += " active";
        }
        document.getElementById("defaultOpen").click();
    </script>
    <script>
        $(document).ready(function() {
            $(".addProducto").submit(function(event) {
                event.preventDefault(); 

                var formData = $(this).serialize()+ '&action=add';

                $.ajax({
                    type: "POST",
                    url: "/Controllers/ProductoController.php",
                    data: formData,
                    dataType: "json",
                    success: function(response) {
                        console.log("Response from server:", response);
                        if (response.success) {
                            alert("Producto agregado correctamente!"); 
                            $(".addProducto")[0].reset();
                            fetchProducts(); 
                        } else {
                            alert("Error: " + response.message);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.log("AJAX error:", xhr.responseText);
                        alert("Failed to send request. Check network or server.");
                    }
                });
            });
            function fetchProducts() {
                console.log("Fetching products...");
                $.ajax({
                    url: "/Controllers/ProductoController.php",
                    method: "GET",
                    dataType: "json",
                    success: function(response) {
                        console.log("Products fetched:", response);
                        var tableBody = $("#tableProductos");
                        tableBody.empty();

                        if (response.length > 0) {
                            $.each(response, function(index, product) {
                                var row = `<tr>
                                            <td>${product.ID}</td>
                                            <td>${product.PRODNOMBRE}</td>
                                            <td>${product.STOCK}</td>
                                            <td>$${product.PRECIOUNI}</td>
                                            <td class="action">
                                                <a data-id="${product.ID}" class="removeProd">
                                                    <i class="fa fa-trash"></i> Eliminar
                                                </a>
                                                <input id="actualizarProductos" class="update" type="submit" value="update" name="updateBtn">
                                            </td>
                                        </tr>`;
                                tableBody.append(row);
                            });
                        } else {
                            tableBody.html("<tr><td colspan='5'><span>No products added</span></td></tr>");
                        }
                    },
                    error: function(xhr, status, error) {
                        console.log("Error fetching products:", xhr.responseText);
                    }
                });
            }
            fetchProducts();


            $(document).on("click", ".removeProd", function(e) {
                e.preventDefault();
                if (!confirm("Eliminar del carrito?")){
                    return;
                } 
                var id = $(this).data("id");
                $.ajax({
                    url: "/Controllers/ProductoController.php",
                    type: "POST",
                    data: {
                        action: "delete",
                        id: id
                    },
                    dataType: "json",
                    success: function(response) {
                        if (response.success) {
                            alert("Eliminado correctamente!");
                            fetchProducts(); 
                        } else {
                            alert("Error al eliminar main: " + response.message);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.log("AJAX delete error:", xhr.responseText);
                    }
                });
            });

            $(document).on("click", "#actualizarProductos", function(e) {
                e.preventDefault();

                var row = $(this).closest("tr");
                var id = row.find("td:eq(0)").text();
                var nombre = row.find("td:eq(1)").text();
                var cantidad = row.find("td:eq(2)").text();
                var precio = row.find("td:eq(3)").text().replace('$', '');

                $("#updateId").val(id);
                $("#updateNombre").val(nombre);
                $("#updateCantidad").val(cantidad);
                $("#updatePrecio").val(precio);

                $("#updateModal").fadeIn();
            });

            
            $(".close").click(function() {
                $("#updateModal").fadeOut();
            });

            $("#updateForm").submit(function(e) {
                e.preventDefault();
                var formData = $(this).serialize() + '&action=update';

                $.ajax({
                    url: "/Controllers/ProductoController.php",
                    type: "POST",
                    data: formData,
                    dataType: "json",
                    success: function(response) {
                        if (response.success) {
                            alert("Producto actualizado!");
                            $("#updateModal").fadeOut();
                            fetchProducts(); 
                        } else {
                            alert("Error al actualizar: " + response.message);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.log("Update error:", xhr.responseText);
                    }
                });
            });

        });

        $(document).ready(function() {
            $(".addService").submit(function(event) {
                event.preventDefault(); 
                var formData = $(this).serialize()+ '&action=add';
                $.ajax({
                    type: "POST",
                    url: "/Controllers/ServiceController.php",
                    data: formData,
                    dataType: "json",
                    success: function(response) {
                        console.log("Response from server:", response);
                        if (response.success) {
                            alert("Servicio agregado correctamente!"); 
                            $(".addService")[0].reset();
                            fetchServices(); 
                        } else {
                            alert("Error: " + response.message);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.log("AJAX error:", xhr.responseText);
                        alert("Failed to send request. Check network or server.");
                    }
                });
            });

            function fetchServices() {
                console.log("Fetching Services...");
                $.ajax({
                    url: "/Controllers/ServiceController.php",
                    method: "GET",
                    dataType: "json",
                    success: function(response) {
                        console.log("Services fetched:", response);
                        var tableBody = $("#tableServicios");
                        tableBody.empty();

                        if (response.length > 0) {
                            $.each(response, function(index, service) {
                                var row = `<tr>
                                            <td>${service.ID}</td>
                                            <td>${service.ServiceName}</td>
                                            <td>${service.ServicePrice}</td>
                                            <td class="action">
                                                <a data-id="${service.ID}" class="removeServ">
                                                    <i class="fa fa-trash"></i> Eliminar
                                                </a>
                                                <input id="actualizarServicios"class="update" type="submit" value="update" name="updateBtn">
                                            </td>
                                        </tr>`;
                                tableBody.append(row);
                            });
                        } else {
                            tableBody.html("<tr><td colspan='5'><span>No services added</span></td></tr>");
                        }
                    },
                    error: function(xhr, status, error) {
                        console.log("Error fetching services:", xhr.responseText);
                    }
                });
            }
            fetchServices();

            $(document).on("click", ".removeServ", function(e) {
                e.preventDefault();
                if (!confirm("Eliminar del carrito?")){
                    return;
                } 
                var id = $(this).data("id");
                $.ajax({
                    url: "/Controllers/ServiceController.php",
                    type: "POST",
                    data: {
                        action: "delete",
                        id: id
                    },
                    dataType: "json",
                    success: function(response) {
                        if (response.success) {
                            alert("Eliminado correctamente!");
                            fetchServices(); 
                        } else {
                            alert("Error al eliminar: " + response.message);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.log("AJAX delete error:", xhr.responseText);
                    }
                });
            });

            $(document).on("click", "#actualizarServicios", function(e) {
                e.preventDefault();

                var row = $(this).closest("tr");
                var id = row.find("td:eq(0)").text();
                var nombre = row.find("td:eq(1)").text();
                var precio = row.find("td:eq(2)").text().replace('$', '');

                $("#upServId").val(id);
                $("#upServName").val(nombre);
                $("#upPrice").val(precio);

                $("#upServicePopUp").fadeIn();
            });

            
            $(".close").click(function() {
                $("#upServicePopUp").fadeOut();
            });

            $("#updateServiceForm").submit(function(e) {
                e.preventDefault();
                var formData = $(this).serialize() + '&action=update';

                $.ajax({
                    url: "/Controllers/ServiceController.php",
                    type: "POST",
                    data: formData,
                    dataType: "json",
                    success: function(response) {
                        if (response.success) {
                            alert("Servicio actualizado!");
                            $("#upServicePopUp").fadeOut();
                            fetchServices(); 
                        } else {
                            alert("Error al actualizar: " + response.message);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.log("Update error:", xhr.responseText);
                    }
                });
            });
        });
    </script>   
</body>
</html>