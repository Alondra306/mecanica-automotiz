<?php

header('Content-Type: application/json');

require_once '../Models/VentaModel.php';
#require_once __DIR__ . '/../Models/ProductoModel.php';
$db = new VentaModel();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fecha = $_POST['fecha'] ?? '';
    $totalItems = $_POST['totalItems'] ?? '';
    $totalFinal = $_POST['totalFinal'] ?? '';

    if ($totalItems>0 && $totalFinal>0) {
        $response = $db->addVenta($fecha, $totalItems, $totalFinal);
        echo json_encode(["success" => true, "message" => "Venta agregado correctamente CONTROLLER"]);
    } else {
        echo json_encode(["success" => false, "message" => "Datos invalidos"]);
    }
    exit;
}

?>