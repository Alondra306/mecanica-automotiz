<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");


require_once '../vendor/autoload.php';

class EmailSender {
    private $smtpUser = 'alejandro.limon4634@alumnos.udg.mx';
    private $smtpPass = 'gqyh tdwl qgub hmyf';
    private $smtpHost = 'smtp.gmail.com';
    private $smtpPort = 587;

    public function sendReceipt($data) {
        $mail = new PHPMailer(true);
        
        try {
            $mail->isSMTP();
            $mail->Host = $this->smtpHost;
            $mail->SMTPAuth = true;
            $mail->Username = $this->smtpUser;
            $mail->Password = $this->smtpPass;
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = $this->smtpPort;
            $mail->setFrom($this->smtpUser, 'Mecánica CUT');
            $mail->addAddress($data['email'], $data['nombre'] ?? 'Cliente');

            $mail->isHTML(true);
            $mail->Subject = '📋 Recibo de Compra - Mecánica CUT';
            $mail->Body = $this->buildReceiptBody($data);

            $mail->CharSet = 'UTF-8';
            $mail->Encoding = 'base64';

            return $mail->send();
            
        } catch (Exception $e) {
            error_log('Error enviando email: ' . $mail->ErrorInfo);
            return false;
        }
    }
    
    private function buildReceiptBody($data) {
        $itemsTable = '';
        $total = 0;
        
        foreach ($data['items'] as $item) {
            $precio = $item['precio'] ?? 0;
            $cantidad = $item['cantidad'] ?? 1;
            $precioUnitario = $precio / $cantidad;
            
            $itemsTable .= "
                <tr>
                    <td style='padding: 10px; border-bottom: 1px solid #eee;'>{$item['nombre']}</td>
                    <td style='padding: 10px; border-bottom: 1px solid #eee; text-align: center;'>{$cantidad}</td>
                    <td style='padding: 10px; border-bottom: 1px solid #eee; text-align: right;'>$".number_format($precioUnitario, 2)."</td>
                    <td style='padding: 10px; border-bottom: 1px solid #eee; text-align: right;'>$".number_format($precio, 2)."</td>
                </tr>
            ";
            $total += $precio;
        }

        return "
            <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;'>
                <h2 style='color: #2c3e50;'>Recibo de Compra</h2>
                <p>Fecha: ".($data['fecha'] ?? date('d/m/Y'))."</p>
                <p style='margin-bottom: 20px;'>Gracias por su compra en Mecánica CUT</p>
                
                <table style='width: 100%; border-collapse: collapse; margin-bottom: 30px;'>
                    <thead>
                        <tr style='background-color: #f5f5f5;'>
                            <th style='padding: 12px; text-align: left; border-bottom: 2px solid #ddd;'>Descripción</th>
                            <th style='padding: 12px; text-align: center; border-bottom: 2px solid #ddd;'>Cantidad</th>
                            <th style='padding: 12px; text-align: right; border-bottom: 2px solid #ddd;'>P. Unitario</th>
                            <th style='padding: 12px; text-align: right; border-bottom: 2px solid #ddd;'>Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        $itemsTable
                        <tr>
                            <td colspan='3' style='padding: 12px; text-align: right; font-weight: bold; border-top: 2px solid #ddd;'>Total:</td>
                            <td style='padding: 12px; text-align: right; font-weight: bold; border-top: 2px solid #ddd;'>$".number_format($total, 2)."</td>
                        </tr>
                    </tbody>
                </table>
                
                <p style='font-size: 0.9em; color: #777;'>
                    Este es un comprobante automático, no requiere firma.
                </p>
            </div>
        ";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            throw new Exception('Datos JSON inválidos');
        }

        if (empty($input['email']) || empty($input['items'])) {
            throw new Exception('Email y items son requeridos');
        }

        $sender = new EmailSender();
        $success = $sender->sendReceipt([
            'email' => $input['email'],
            'fecha' => $input['fecha'] ?? date('d/m/Y'),
            'items' => $input['items'],
            'nombre' => 'Cliente'
        ]);

        echo json_encode([
            'success' => $success,
            'message' => $success ? 'Recibo enviado' : 'Error al enviar'
        ]);

    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Método no permitido'
    ]);
}