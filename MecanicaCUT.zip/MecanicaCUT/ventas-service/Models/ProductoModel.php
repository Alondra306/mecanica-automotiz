<?php
class Database {
    private $host = 'inventory-db';
    private $username = 'root';
    private $password = 'Woojinscub143';
    private $database = 'INVENTARIO';
    private $conn;

    public function __construct() {
        try {
            $this->conn = new PDO("mysql:host={$this->host};dbname={$this->database};", $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            echo("<style> h2{text-align: center; padding-top: 30px;}</style><h2>Ocurrio un error intenta al rato</h2>");
            die();
        }
    }

    public function insertProduct($name, $stock, $price) {
        try {
            $stmt = $this->conn->prepare("INSERT INTO PRODUCTOS (PRODNOMBRE, STOCK, PRECIOUNI) VALUES (:PRODNOMBRE, :STOCK, :PRECIOUNI)");
            $stmt->bindParam(':PRODNOMBRE', $name);
            $stmt->bindParam(':STOCK', $stock, PDO::PARAM_INT);
            $stmt->bindParam(':PRECIOUNI', $price, PDO::PARAM_INT);
            $stmt->execute();
            return ["success" => true, "message" => "Producto agregado correctamente"];
        } catch (PDOException $e) {
            return ["success" => false, "message" => "Error al agregar producto: " . $e->getMessage()];
        }
    }
    public function deleteProduct($id){
        try{
            $stmt= $this->conn->prepare("DELETE FROM PRODUCTOS WHERE ID= :id");
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            return ["success" => true, "message" => "Producto eliminado"];

        }catch(PDOException $e){
            return ["success" => false, "message" => "Error: " . $e->getMessage()];
        }
    }

    public function updateProduct($id, $nombre, $cantidad, $precio){
        try{
           
            $stmt = $this->conn->prepare("UPDATE PRODUCTOS SET PRODNOMBRE=:PRODNOMBRE, PRECIOUNI=:PRECIOUNI, STOCK=:STOCK WHERE ID=:ID");
            $stmt->bindParam(':PRODNOMBRE', $nombre);
            $stmt->bindParam(':STOCK', $cantidad, PDO::PARAM_INT);
            $stmt->bindParam(':PRECIOUNI', $precio, PDO::PARAM_INT);
            $stmt->bindParam(':ID', $id);
            $stmt->execute();

        }catch(PDOException $e){
            return ["success" => false, "message" => "Error: " . $e->getMessage()];
        }
    }

    public function getProducts() {
        try {
            $stmt = $this->conn->prepare("SELECT * FROM PRODUCTOS");
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC); 
        } catch (PDOException $e) {
            return []; 
        }
    }  
    
    public function getProductById($id){
        try{
            $stmt= $this->conn->prepare("SELECT * FROM PRODUCTOS WHERE ID= :id");
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC);
            return ["success" => true, "message" => "Producto Agregado"];

        }catch(PDOException $e){
            return ["success" => false, "message" => "Error: " . $e->getMessage()];
        }
    }

    public function insertService($servicename, $serviceprice){
        try{
            $stmt = $this->conn->prepare("INSERT INTO SERVICIOS (ServiceName, ServicePrice) VALUES (:ServiceName, :ServicePrice)");
            $stmt->bindParam(':ServiceName', $servicename);
            $stmt->bindParam(':ServicePrice', $serviceprice, PDO::PARAM_INT);
            $stmt->execute();
            return ["success" => true, "message" => "Producto agregado correctamente"];

        }catch(PDOException $e){
            return["success" => false, "message"=>"Error al agregar servicio: ". $e->getMessage()];
        }
    }

    public function deleteService($id){
        try{
            $stmt= $this->conn->prepare("DELETE FROM SERVICIOS WHERE ID= :id");
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            return ["success" => true, "message" => "Servicio eliminado"];

        }catch(PDOException $e){
            return ["success" => false, "message" => "Error: " . $e->getMessage()];
        }
    }

    public function updateService($id, $nombre, $precio){
        try{
            $stmt = $this->conn->prepare("UPDATE SERVICIOS SET ServiceName=:ServiceName, ServicePrice=:ServicePrice WHERE ID=:ID");
            $stmt->bindParam(':ServiceName', $nombre);
            $stmt->bindParam(':ServicePrice', $precio, PDO::PARAM_INT);
            $stmt->bindParam(':ID', $id);
            $stmt->execute();

        }catch(PDOException $e){
            return ["success" => false, "message" => "Error: " . $e->getMessage()];
        }
    }

    public function getServices() {
        try {
            $stmt = $this->conn->prepare("SELECT * FROM SERVICIOS");
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC); 
        } catch (PDOException $e) {
            return []; 
        }
    } 

}
?>
