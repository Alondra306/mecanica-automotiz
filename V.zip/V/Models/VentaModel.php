<?php
class VentaModel {
    private $host = 'localhost';
    private $username = 'evelin';
    private $password = 'Woojinscub143';
    private $database = 'ventas';
    private $conn;

    public function __construct() {
        try {
            $this->conn = new PDO("mysql:host={$this->host};dbname={$this->database};", $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            echo("<style> h2{text-align: center; padding-top: 30px;}</style><h2>Ocurrio un error intenta al rato</h2>");
            die();
        }
    }

    public function addVenta($fecha, $totalItems, $totalFinal){
        try{
            $stmt = $this->conn->prepare("INSERT INTO ventas (fecha, total_items, total_final) VALUES (:fecha, :total_items, :total_final)");
            $stmt->bindParam(':fecha', $fecha);
            $stmt->bindParam(':total_items', $totalItems);
            $stmt->bindParam(':total_final', $totalFinal);
            $stmt->execute();
            return ["success" => true, "message" => "Venta exitosa MODEL"];

        }catch(PDOException $e){
            return ["success" => false, "message" => "Error al agregar producto: " . $e->getMessage()];
        }
    }
}
?>