<?php
header('Content-Type: application/json');
require_once '../Models/ProductoModel.php';

$db = new Database();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])&& $_POST['action'] === 'delete') {
    $id = $_POST['id'];
    if(!empty($id)){
        $result = $db->deleteService($id);
        echo json_encode(["success" => true, "message" => "Servicio eliminado correctamente"]);
    }else{
        echo json_encode(["success" => false, "message" => "Error"]);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST'&&$_POST['action'] === 'add') {
    $ServiceName = $_POST['nombreServicio'] ?? '';
    $ServicePrice = $_POST['precioServicio'] ?? '';

    if (!empty($ServiceName) && is_numeric($ServicePrice)) {
        $response = $db->insertService($ServiceName, $ServicePrice);
        echo json_encode(["success" => true, "message" => "Producto agregado correctamente"]);
    } else {
        echo json_encode(["success" => false, "message" => "Datos invalidos"]);
    }
    exit;
}

if($_SERVER['REQUEST_METHOD']==='POST' && $_POST['action']==='update'){
    $id = $_POST['id'] ?? null;
    $nombre = $_POST['nombreProducto'] ?? '';
    $precio = $_POST['precio'] ?? 0;

    if (!empty($id) && !empty($nombre) && is_numeric($precio)) {
        $response = $db->updateService($id, $nombre, $precio);
        echo json_encode(["success" => true, "message" => "Servicio actualizado correctamente"]);
    }else{
        echo json_encode(["success" => false, "message" => "Datos invalidos"]);
    }
    exit;
}

if($_SERVER['REQUEST_METHOD']==='GET'){
    $services = $db->getServices();
    echo json_encode($services);
    exit;
}
echo json_encode(["success" => false, "message" => "Invalid request"]);
exit;

?>