<?php
header('Content-Type: application/json');
require_once '../Models/ProductoModel.php';

$db = new Database();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $id = $_POST['id'];
    if(!empty($id)){
        $result = $db->deleteProduct($id);
        echo json_encode(["success" => true, "message" => "Producto eliminado correctamente"]);
    }else{
        echo json_encode(["success" => false, "message" => "Error"]);
    }
    exit;
}

if($_SERVER['REQUEST_METHOD']==='POST' && $_POST['action']==='update'){
    $id = $_POST['id'] ?? null;
    $nombre = $_POST['nombreProducto'] ?? '';
    $cantidad = $_POST['cantidad'] ?? 0;
    $precio = $_POST['precio'] ?? 0;

    if (!empty($id) && !empty($nombre) && is_numeric($cantidad) && is_numeric($precio)) {
        $response = $db->updateProduct($id, $nombre, $cantidad, $precio);
        echo json_encode(["success" => true, "message" => "Producto actualizado correctamente"]);
    }else{
        echo json_encode(["success" => false, "message" => "Datos invalidos"]);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST'&& $_POST['action'] === 'add') {
    $PRODNOMBRE = $_POST['nombreProducto'] ?? '';
    $STOCK = $_POST['cantidad'] ?? '';
    $PRECIOUNI = $_POST['precio'] ?? '';

    if (!empty($PRODNOMBRE) && is_numeric($STOCK) && is_numeric($PRECIOUNI)) {
        $response = $db->insertProduct($PRODNOMBRE, $STOCK, $PRECIOUNI);
        echo json_encode(["success" => true, "message" => "Producto agregado correctamente"]);
    } else {
        echo json_encode(["success" => false, "message" => "Datos invalidos"]);
    }
    exit;
}
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $producto = $db->getProductById($id); 
    echo json_encode($producto);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $products = $db->getProducts();
    echo json_encode($products);
    exit;
}

echo json_encode(["success" => false, "message" => "Invalid request"]);
exit;