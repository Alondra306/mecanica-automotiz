<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<title>MecanicaCUT</title>
<link href="VentaStyle.css" rel="stylesheet" type="text/css"> 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
    <div class= "c">
        <?php include 'header.php'; ?>
        <?php include '../Models/VentaModel.php';
            $db = new VentaModel();
        ?>
        <div class="container">
            <h2>Ventas</h2>
            <div class="upperMenu">
                <label>Fecha: <span id="currentDate"></span></label><br>
                <label>Producto:</label>
                <select id="productoSelect" name="producto">
                    <option selected disabled>-- Selecciona --</option>
                </select>
            <button class="btn">Agregar</button>
            <br><br>
        </div>
        <br>
        <div class="tableContainer">
            <table>
                <thead>
                    <th>Num.</th>
                    <th>Nombre</th>
                    <th>Total</th>
                </thead>
                <tbody id="productTableBody">

                </tbody>
                <tr class="bottomTable">
                    <td colspan="2">Total Final: </td>
                    <td></td>
                </tr>
            </table>
            <button class="FinalizarCompra">Finalizar</button>
        </div>
        <br>
    </div>    
</div>
<script> 
    const fechaObj = new Date(); 
    const yyyy = fechaObj.getFullYear();
    const mm = String(fechaObj.getMonth() + 1).padStart(2, '0');
    const dd = String(fechaObj.getDate()).padStart(2, '0');
    const formattedFecha = `${yyyy}-${mm}-${dd}`; 

    const today = new Date(); 
    const formattedDate = today.toLocaleDateString(); 
    document.getElementById("currentDate").textContent = formattedDate; 

    fetch('../Controllers/ProductoController.php') //endpoint
        .then(response => response.json())
        .then(data => {
            const select = document.getElementById("productoSelect");
            data.forEach(producto => {
                const option = document.createElement("option");
                option.value = producto.ID;
                option.textContent = producto.PRODNOMBRE;
                select.appendChild(option);
            });
        })
        .catch(error => console.error('Error loading products:', error));
</script> 
<script>
    $(document).ready(function () {
        $('.btn').on('click', function () {
            const selectedID = $('#productoSelect').val();
            if (!selectedID) {
                alert('Por favor, selecciona un producto.');
                return;
            }
            $.ajax({
                url: '../Controllers/ProductoController.php',
                method: 'GET',
                data: { id: selectedID },
                dataType: 'json',
                success: function (producto) {
                    const subtotalInicial = (producto.PRECIOUNI * 1).toFixed(2);
                    const rowCount = $('#productTableBody tr').length + 1;
                    const newRow = `
                        <tr>
                            <td>${rowCount}</td>
                            <td>${producto.PRODNOMBRE}</td>
                            <td class="subtotal">${subtotalInicial}</td>
                            <td class="canti">
                                <input type="number" name="cantidad" min="1" value="1" class="cantidadInput" data-precio="${producto.PRECIOUNI}">
                            </td>
                            <td class="action">
                                <a href="#" class="removeBtn" "><i class="fa fa-trash"></i> Eliminar</a>
                            </td>
                        </tr>
                    `;
                    $('#productTableBody').append(newRow);
                    updateFinalTotal();
                },
                error: function (xhr, status, error) {
                    console.error('Error fetching product:', error);
                }
            });
        });

        $('#productTableBody').on('input', '.cantidadInput', function(){
            const cantidad = parseInt($(this).val()) || 0;
            const precioUnitario = parseFloat($(this).data('precio'));
            const subtotal = cantidad * precioUnitario;
            $(this).closest('tr').find('.subtotal').text(subtotal.toFixed(2));
            updateFinalTotal();

        });
        function updateFinalTotal(){
            let total = 0;
            $('#productTableBody .subtotal').each(function () {
                total += parseFloat($(this).text()) || 0;
            });
            $('.bottomTable td:last').text(`$${total.toFixed(2)}`);
        }
        $('#productTableBody').on('click', '.removeBtn', function (e) {
            e.preventDefault();
            if (confirm('Eliminar del carrito?')) {
                $(this).closest('tr').remove();
                updateFinalTotal();
            }
        });

        $('.FinalizarCompra').on('click', function(){
            const fecha = formattedFecha;
            let totalItems = 0;
            let totalFinal = 0;

            $('#productTableBody tr').each(function () {
                const cantidad = parseInt($(this).find('.cantidadInput').val()) || 0;
                const subtotal = parseFloat($(this).find('.subtotal').text()) || 0;
                totalItems += cantidad;
                totalFinal += subtotal;
            });

            if (totalItems === 0) {
                alert('No hay productos en la venta.');
                return;
            }

            $.ajax({
                url: '../Controllers/VentaController.php',
                method: 'POST',
                data: {
                    fecha: fecha,
                    totalItems: totalItems,
                    totalFinal: totalFinal.toFixed(2)
                },
                success: function(response) {
                    console.log("Response from server:", response);
                    if(response.success){
                        alert('Venta registrada con éxito.');
                        $('#productTableBody').empty();
                        $('.bottomTable td:last').text('$0.00');
                    }else{
                        alert("Error al realizar venta: " + response.message);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error al finalizar la venta:', error);
                    alert('Ocurrió un error al guardar la venta.');
                }
            });
        });
    });
</script>
</body>
</html>