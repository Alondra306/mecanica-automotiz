<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
date_default_timezone_set('America/Mexico_City');

require '../Models/DB_Modal.php';
#require_once __DIR__ . '/../Models/DBModel.php';

global $pdo;
function getData() {
    return json_decode(file_get_contents("php://input"), true) ?? [];
}

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        try {
            if (isset($_GET['start']) && isset($_GET['end'])) {
            
                $sql = "SELECT COUNT(*) as count FROM citas WHERE fecha_hora BETWEEN ? AND ?";
                $params = [$_GET['start'], $_GET['end']];
                if (isset($_GET['exclude']) && is_numeric($_GET['exclude'])) {
                    $sql .= " AND id != ?";
                    $params[] = $_GET['exclude'];
                }
            
                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);
                $result = $stmt->fetch();

                echo json_encode([
                    'success' => true,
                    'count' => (int)$result['count']
                ]);
                exit;
            } else {
                $stmt = $pdo->query("SELECT 
                                id, 
                                nombre, 
                                apellido, 
                                email, 
                                codigo_pais, 
                                telefono, 
                                servicios,
                                DATE_FORMAT(fecha_hora, '%Y-%m-%dT%H:%i') as fecha_hora,
                                status FROM citas ORDER BY fecha_hora ASC");

                $citas = $stmt->fetchAll(PDO::FETCH_ASSOC);

                header('Content-Type: application/json');
                echo json_encode([
                    'success' => true,
                    'data' => $citas ? $citas : [],
                    'count' => count($citas),
                    'message' => count($citas) ? 'Citas encontradas' : 'No hay citas registradas'
                ]);
            }
            } catch (Exception $e) {
                http_response_code(500);
                echo json_encode([
                    'success' => false,
                    'message' => 'Error al obtener citas',
                    'error' => $e->getMessage()
                ]);
            }
        break;

    case 'POST':
        $data = getData();
    
        if (!$data || !isset($data['nombre'], $data['apellido'], $data['email'], $data['codigo_pais'], $data['telefono'], $data['servicios'], $data['fecha_hora'])) {
            http_response_code(400);
            echo json_encode(["error" => "Faltan campos requeridos"]);
            exit;
        }
        
        try {
            $appointmentDateTime = new DateTime($data['fecha_hora']);
            $now = new DateTime();
            if ($appointmentDateTime < $now) {
                http_response_code(400);
                echo json_encode(["error" => "No se pueden agendar citas en el pasado"]);
                exit;
            }
            $startTime = (clone $appointmentDateTime)->modify('-59 minutes');
            $endTime = (clone $appointmentDateTime)->modify('+59 minutes');

            $stmt = $pdo->prepare("SELECT COUNT(*) FROM citas WHERE fecha_hora BETWEEN ? AND ?");
            $stmt->execute([
                $startTime->format('Y-m-d H:i:s'),
                $endTime->format('Y-m-d H:i:s')
            ]);

            $conflictingAppointments = $stmt->fetchColumn();

            if ($conflictingAppointments > 0) {
                http_response_code(400);
                $text = 'Ya existe una cita programada dentro de 1 hora antes o despues de este horario';
                echo json_encode(${$text});
                exit;
            }


            $sql = "INSERT INTO citas (nombre, apellido, email, codigo_pais, telefono, servicios, fecha_hora, status) VALUES (:nombre, :apellido, :email, :codigo_pais, :telefono, :servicios, :fecha_hora, :status)";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':nombre' => $data['nombre'],
                ':apellido' => $data['apellido'],
                ':email' => $data['email'],
                ':codigo_pais' => $data['codigo_pais'],
                ':telefono' => $data['telefono'],
                ':servicios' => $data['servicios'],
                ':fecha_hora' => $data['fecha_hora'],
                ':status' => 'pending'
            ]);
            
            $lastId = $pdo->lastInsertId();
            $stmt = $pdo->prepare("SELECT * FROM citas WHERE id = ?");
            $stmt->execute([$lastId]);
            $newAppointment = $stmt->fetch();
            
            echo json_encode($newAppointment);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                "error" => "Error al insertar en la base de datos", 
                "mensaje" => $e->getMessage(),
                "sql" => $sql,
                "data" => $data
            ]);
        }
        break;
    
    case 'PUT':
        $data = getData();

        if (!$data || !isset($data['id'])) {
            http_response_code(400);
            $text = "ID y datos requeridos para actualizar";
            echo json_encode($text);
            exit;
        }
        
        try {
            $appointmentDateTime = new DateTime($data['fecha_hora']);
            $now = new DateTime();

            $stmt = $pdo->prepare("SELECT fecha_hora FROM citas WHERE id = ?");
            $stmt->execute([$data['id']]);
            $existingAppointment = $stmt->fetch();
            $existingTime = new DateTime($existingAppointment['fecha_hora'], new DateTimeZone('America/Mexico_City'));
            if ($appointmentDateTime->format('Y-m-d H:i') !== $existingTime->format('Y-m-d H:i')) {
                if ($appointmentDateTime < $now) {
                    http_response_code(400);
                    $text = "No se pueden agendar citas en el pasado";
                    echo json_encode($text);
                    exit;
                }
            }
            $startTime = (clone $appointmentDateTime)->modify('-59 minutes');
            $endTime = (clone $appointmentDateTime)->modify('+59 minutes');

            $stmt = $pdo->prepare("SELECT COUNT(*) FROM citas WHERE fecha_hora BETWEEN ? AND ? AND id != ?");
            $stmt->execute([
                $startTime->format('Y-m-d H:i:s'),
                $endTime->format('Y-m-d H:i:s'),
                $data['id']
            ]);

            $conflictingAppointments = $stmt->fetchColumn();

            if ($conflictingAppointments > 0) {
                http_response_code(400);
                $text = 'Ya existe una cita programada dentro de 1 hora antes o despues de este horario';
                echo json_encode($text);
                exit;
            }
            $stmt = $pdo->prepare("UPDATE citas SET nombre = ?, apellido = ?, email = ?, codigo_pais = ?, telefono = ?, servicios = ?, fecha_hora = ? WHERE id = ?");
            $stmt->execute([
                $data['nombre'],
                $data['apellido'],
                $data['email'],
                $data['codigo_pais'],
                $data['telefono'],
                $data['servicios'],
                $data['fecha_hora'],
                $data['id']
            ]);
            
            $stmt = $pdo->prepare("SELECT * FROM citas WHERE id = ?");
            $stmt->execute([$data['id']]);
            $updatedAppointment = $stmt->fetch();
            
            echo json_encode($updatedAppointment);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(["error" => "Error al actualizar cita", "mensaje" => $e->getMessage()]);
        }
        break;


    case 'DELETE':
        $id = $_GET['id'] ?? null;
        
        if (!$id) {
            http_response_code(400);
            echo json_encode(["error" => "ID requerido"]);
            exit;
        }
        
        try {
            $stmt = $pdo->prepare("SELECT * FROM citas WHERE id = ?");
            $stmt->execute([$id]);
            $deletedAppointment = $stmt->fetch();

            $stmt = $pdo->prepare("DELETE FROM citas WHERE id = ?");
            $stmt->execute([$id]);
            
            echo json_encode($deletedAppointment);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(["error" => "Error al eliminar cita", "mensaje" => $e->getMessage()]);
        }
        break;


    case 'PATCH':
        $data = getData();
        
        if (!$data || !isset($data['id'])) {
            http_response_code(400);
            echo json_encode(["error" => "ID requerido"]);
            exit;
        }
        
        try {
            $stmt = $pdo->prepare("UPDATE citas SET status = ? WHERE id = ?");
            $stmt->execute(['completed', $data['id']]);

            $stmt = $pdo->prepare("SELECT * FROM citas WHERE id = ?");
            $stmt->execute([$data['id']]);
            $updatedAppointment = $stmt->fetch();
            
            echo json_encode($updatedAppointment);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(["error" => "Error al actualizar estado", "mensaje" => $e->getMessage()]);
        }
        break;

    default:
        http_response_code(405);
        echo json_encode(["error" => "Método no permitido"]);
        break;
}