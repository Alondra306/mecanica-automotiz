<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MecanicaCUT</title>
    <link rel="stylesheet" href="css/CitasStyle.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.min.css">
    <link rel="icon" href="data:,">
    <?php include 'header.php';?>
</head>
<body>
    <div class="container">
        <div class="nav-buttons">
            <button class="btn btn-primary" onclick="showView('day')">Vista Diaria</button>
            <button class="btn btn-primary" onclick="showView('week')">Vista Semanal</button>
            <button class="btn btn-primary" onclick="showView('month')">Vista Mensual</button>
            <button class="btn btn-success" onclick="showModal()">Nueva Cita</button>
        </div>

        <div class="filter-container">
            <div class="filter-item">
                <h3>Filtrar por:</h3>
                <select id="filterSelect" onchange="filterAppointments()">
                    <option value="all">Todas las citas</option>
                    <option value="pending">Pendientes</option>
                    <option value="completed">Completadas</option>
                </select>
            </div>
        </div>

        <div class="calendar-view" id="calendarView"></div>

        <div class="modal" id="newAppointmentModal">
            <div class="modal-content">
                <span class="close-modal" onclick="hideModal()">&times;</span>
                <h2>Nueva Cita</h2>
                <form id="appointmentForm">
                    <label for="nombre">Nombre:</label>
                    <input type="text" id="nombre" name="nombre" required><br>

                    <label for="apellido">Apellido:</label>
                    <input type="text" id="apellido" name="apellido" required><br>

                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required><br>

                    <label for="telefono">Teléfono:</label>
                    <input type="tel" id="telefono" name="telefono" required><br>
                    <input type="hidden" name="codigo_pais" id="codigo_pais">

                    <label for="servicio">Servicios:</label>
                    <div class="accordion">
                        <div class="accordion-item" id="servicios-container">
                            <button type="button" class="accordion-header btn-acordeon">Servicios<span class="arrow">⌄</span> </button>
                        </div>
                    </div><br>
                    <input type="hidden" id="servicios-seleccionados" name="servicio">
                    <label for="fecha-hora">Selecciona fecha y hora:</label>
                    <input type="datetime-local" id="fecha-hora" name="fecha_hora" required><br>

                    <button type="submit"  class="btn btn-success">Registrarse</button>
                </form>
            </div>
        </div>

        <div class="modal" id="dailyAppointmentsModal">
            <div class="modal-content">
            <span class="close-modal" onclick="hideModal()">&times;</span>
             <h2 id="modalTitle"></h2>
             <div id="dailyAppointmentsList"></div>
             </div>
        </div>

        <div class="notification" id="notification"></div>
    </div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const phoneInput = document.querySelector("#telefono");
    const iti = window.intlTelInput(phoneInput, {
        initialCountry: "mx",
        preferredCountries: ["mx", "us", "es", "co", "ar", "br", "cl"],
        separateDialCode: true,
        utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js"
    });
    phoneInput.addEventListener('input', function() {
        document.getElementById('codigo_pais').value = iti.getSelectedCountryData().dialCode;
    });
});
</script>
<script src="js/Citas_Front.js"></script>
</body>
</html>